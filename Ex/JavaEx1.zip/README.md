# JavaEx
## My personal Java exersice project.  
Hello,Github!
